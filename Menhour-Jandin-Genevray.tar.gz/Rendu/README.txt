tests:

- frame.c : crée un root bleu avec un frame contenant du texte et un bouton, qui contient une image. Le frame et le bouton sont en relief.

- bouton.c : crée un root bleu avec un bouton simple en relief contenant du texte.

- hello_world.c : crée un root bleu avec un toplevel, qui contient un bouton en relief et un  autre top level.
